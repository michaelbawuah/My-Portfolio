Project logo pack for Michael Baffour Awuah

Five original project marks created for the portfolio.
Transparent PNGs, 1254 x 1254 pixels.

NavoX: cobalt/cyan orbital N and X.
Fluxion: violet/cobalt folded F.
MarketLab: emerald/mint M and market bars.
ModelForge: amber/orange M and open hexagonal brackets.
ToolRet: blue/azure converging retrieval paths.
